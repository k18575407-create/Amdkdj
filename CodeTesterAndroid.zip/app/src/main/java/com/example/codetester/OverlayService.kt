package com.example.codetester

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.View
import android.view.MotionEvent
import android.os.Handler
import android.os.Looper
import kotlin.random.Random

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private var countView: TextView? = null
    private var statusView: TextView? = null
    private var running = false
    private var count = 0
    private var rate = 5
    private val handler = Handler(Looper.getMainLooper())
    private val task = object : Runnable {
        override fun run() {
            if (!running) return
            count++
            val fakeCode = Random.nextInt(0, 1_000_000).toString().padStart(6, '0')
            countView?.text = "تلاش آزمایشی: $count\\nکد ساختگی آخر: $fakeCode"
            statusView?.text = "در حال شبیه‌سازی — هیچ کدی به بازی ارسال نمی‌شود"
            handler.postDelayed(this, (1000L / rate).coerceAtLeast(50L))
        }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    private fun showPanel() {
        if (panel != null) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.rgb(20, 30, 50))
        }
        val title = TextView(this).apply {
            text = "⚡ Code Tester"
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(8))
        }
        countView = TextView(this).apply {
            text = "تلاش آزمایشی: 0\\nکد ساختگی آخر: ------"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(6))
        }
        statusView = TextView(this).apply {
            text = "متوقف"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, dp(8))
        }
        val speedRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun button(label: String, action: () -> Unit): Button =
            Button(this).apply { text = label; setOnClickListener { action() } }
        speedRow.addView(button("سرعت −") { rate = (rate - 1).coerceAtLeast(1); statusView?.text = "سرعت: $rate تلاش/ثانیه" },
            LinearLayout.LayoutParams(0, dp(44), 1f))
        speedRow.addView(button("سرعت +") { rate = (rate + 1).coerceAtMost(20); statusView?.text = "سرعت: $rate تلاش/ثانیه" },
            LinearLayout.LayoutParams(0, dp(44), 1f))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("شروع") {
            if (!running) { running = true; statusView?.text = "در حال شبیه‌سازی"; handler.post(task) }
        }, LinearLayout.LayoutParams(0, dp(44), 1f))
        actions.addView(button("توقف") {
            running = false; handler.removeCallbacks(task); statusView?.text = "متوقف شد"
        }, LinearLayout.LayoutParams(0, dp(44), 1f))
        val close = button("بستن پنل") { stopSelf() }
        root.addView(title)
        root.addView(countView)
        root.addView(statusView)
        root.addView(speedRow)
        root.addView(actions)
        root.addView(close)
        val type = if (android.os.Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            dp(280), WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = dp(12); y = dp(100) }
        root.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; startX=params.x; startY=params.y; return true }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = (startX + (downX-e.rawX).toInt()).coerceAtLeast(0)
                        params.y = (startY + (e.rawY-downY).toInt()).coerceAtLeast(0)
                        wm.updateViewLayout(root, params); return true
                    }
                }
                return false
            }
        })
        panel = root
        wm.addView(root, params)
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(task)
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
